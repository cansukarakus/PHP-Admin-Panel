<?php

session_start();
ob_start();

$servername = "localhost";
$username = "root";
$password = "";

try {
  $conn = new PDO("mysql:host=$servername;dbname=restaurant", $username, $password);
  // set the PDO error mode to exception
  



} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}
?>