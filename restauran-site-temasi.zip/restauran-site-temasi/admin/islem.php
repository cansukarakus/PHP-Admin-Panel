<?php 

include("vt.php");


if (isset($_POST['ayarkaydet'])) {
	
	$title=$_POST['title'];
	$description=$_POST['description'];
	$keywords=$_POST['keywords'];
	


	if (!$title) {
		
		header("Location: documentation?durum=bos");

	}

	else{

		$guncelle = $conn->prepare("UPDATE ayarlar SET title=?,description=?,keywords=? WHERE id='1'");

		$update=$guncelle->execute(array($title,$description,$keywords));

		if ($update) {
			header("Location: documentation?durum=yes");
		}

		else{
			header("Location: documentation?durum=no");
		}

	}

}

if (isset($_POST['iletkaydet'])) {
	
	$ad=$_POST['ad'];
	$mail=$_POST['mail'];
	$yazi=$_POST['yazi'];
	
	

		$upd = $conn->prepare("INSERT iletisim SET ad=?,mail=?,yazi=? ");

		$degistir=$upd->execute(array($ad,$mail,$yazi));

		if ($degistir) {
			header("Location: ../iletisimayar.php?durum=yes");
		}

		else{
			header("Location: ../iletisimayar.php?durum=no");
		}

	

if (isset($_POST['hakkaydet'])) {
	
	$metin=$_POST['h_metin'];
	

		$guncelle = $conn->prepare("UPDATE hakkimizda SET h_metin=? WHERE id='1'");

		$update=$guncelle->execute(array($metin));

		if ($update) {
			header("Location: hakkimizdayar.php?durum=yes");
		}

		else{
			header("Location: hakkimizdayar.php?durum=no");
		}

}
}
 ?>