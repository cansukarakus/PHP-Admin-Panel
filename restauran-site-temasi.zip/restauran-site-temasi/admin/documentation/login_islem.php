<?php 

include "../vt.php"; 

if (isset($_POST['login'])) {
	
	$kadi = $_POST['k_adi'];
	$pass = $_POST['sifre'];


	if (!$kadi || !$pass) {
		header("Location: login.php?durum=bosveri");
	}

	else{

		$varmi = $conn->prepare("SELECT * FROM admin WHERE k_adi=? AND sifre=? AND yetki=?");
		$varmi->execute(array($kadi,$pass,1));

		$varmi_say=$varmi->rowCount();


		$admin_cek = $varmi->fetch(PDO::FETCH_ASSOC);

		if ($varmi_say=="1") {
			$_SESSION['login']=true;
			$_SESSION['k_adi']=$admin_cek['k_adi'];
			$_SESSION['sifre']=$admin_cek['sifre'];

			header("Location: index.php?durum=yes");
		}

		else{

			header("Location: login.php?durum=hatali_or_yetkisiz");
		}


	}

}



 ?>